IF NOT EXISTS(SELECT name FROM sys.tables WHERE name='ActiveFlag_Lookup')
BEGIN
CREATE TABLE [dbo].[ActiveFlag_Lookup](
	[ActiveFlagStatus] [bit] NULL,
	[ActiveFlagDescription] [nvarchar](10) NULL
) ON [PRIMARY]

INSERT [dbo].[ActiveFlag_Lookup] ([ActiveFlagStatus], [ActiveFlagDescription]) VALUES (NULL, N'Unknown')
INSERT [dbo].[ActiveFlag_Lookup] ([ActiveFlagStatus], [ActiveFlagDescription]) VALUES (0, N'No')
INSERT [dbo].[ActiveFlag_Lookup] ([ActiveFlagStatus], [ActiveFlagDescription]) VALUES (1, N'Yes')
END