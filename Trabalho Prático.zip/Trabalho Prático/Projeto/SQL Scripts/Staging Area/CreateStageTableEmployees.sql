IF NOT EXISTS (SELECT name FROM sys.tables WHERE name = 'Employees')	
	CREATE TABLE [dbo].[Employees]
	(
		[BusinessEntityID] [int] NOT NULL,
		[NationalIDNumber] [nvarchar](15) NOT NULL,
		[LoginID] [nvarchar](256) NOT NULL,
		[JobTitle] [nvarchar](50) NOT NULL,
		[BirthDate] [date] NOT NULL,
		[MaritalStatus] [nchar](1) NOT NULL,
		[Gender] [nchar](1) NOT NULL,
		[HireDate] [date] NOT NULL,
		[SalariedFlag] [bit] NOT NULL,
		[VacationHours] [smallint] NOT NULL,
		[SickLeaveHours] [smallint] NOT NULL,
		[CreatedDate] [date] NOT NULL,
		[ModifiedDate] [date] NOT NULL,
	)
ELSE
	TRUNCATE TABLE Employees