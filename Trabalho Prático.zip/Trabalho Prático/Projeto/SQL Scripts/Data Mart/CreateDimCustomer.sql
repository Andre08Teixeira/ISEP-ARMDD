IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CreateDimCustomer')
BEGIN
    CREATE TABLE [dbo].[CreateDimCustomer](
        [CustomerKey] [int] IDENTITY(1,1) NOT NULL,
        [PersonType] [int] NOT NULL,
        [PersonTitle] [nvarchar](8) NOT NULL,
        [FirstName] [nvarchar](256) NOT NULL,
        [MiddleName] [nvarchar](256) NOT NULL,
        [LastName] [nvarchar](256) NOT NULL,
        [Gender] [nvarchar](50) NOT NULL, -- Corrigido para nvarchar ou outro tipo apropriado
        CONSTRAINT [PK_CreateDimCustomer] PRIMARY KEY CLUSTERED 
        (
            [CustomerKey] ASC
        ) WITH (
            PAD_INDEX = OFF, 
            STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, 
            ALLOW_ROW_LOCKS = ON, 
            ALLOW_PAGE_LOCKS = ON, 
            OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF
        ) ON [PRIMARY]
    ) ON [PRIMARY]
END
