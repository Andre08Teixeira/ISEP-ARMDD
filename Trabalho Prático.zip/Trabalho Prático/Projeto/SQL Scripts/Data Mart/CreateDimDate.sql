IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CreateDimDate')
BEGIN
    CREATE TABLE [dbo].[CreateDimDate](
        [DateKey] [date] NOT NULL,
        [FullDate] [varchar](50) NOT NULL,
        [Day] [int] NOT NULL,
        [Month] [int] NOT NULL,
        [Year] [int] NOT NULL,
        [Semester] [int] NOT NULL,
        [Quarter] [int] NOT NULL,
        [Trimester] [int] NOT NULL,
        [MonthName] [varchar](50) NOT NULL,
        [Week] [int] NOT NULL,
        [DayNumberOfYear] [int] NOT NULL,
        [DayNumberOfMonth] [int] NOT NULL,
        [DayNumberOfWeek] [int] NOT NULL,
        CONSTRAINT [PK_CreateDimDate] PRIMARY KEY CLUSTERED 
        (
            [DateKey] ASC
        ) WITH (
            PAD_INDEX = OFF, 
            STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, 
            ALLOW_ROW_LOCKS = ON, 
            ALLOW_PAGE_LOCKS = ON, 
            OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF
        ) ON [PRIMARY]
    ) ON [PRIMARY]
END
