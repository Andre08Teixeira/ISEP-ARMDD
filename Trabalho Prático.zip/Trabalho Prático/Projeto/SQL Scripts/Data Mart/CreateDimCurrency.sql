IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CreateDimCurrency')
BEGIN
    CREATE TABLE [dbo].[CreateDimCurrency](
        [CurrencyKey] [int] IDENTITY(1,1) NOT NULL,
        [Name] [nvarchar](50) NOT NULL,
        [CurrencyRateDate] [Date] NOT NULL,
        [FromCurrencyCode] [int] NOT NULL,
        [ToCurrencyCode] [int] NOT NULL,
        [AverageRate] [int] NOT NULL,
        [EndOfDayRate] [int] NOT NULL,
        CONSTRAINT [PK_CreateDimCurrency] PRIMARY KEY CLUSTERED 
        (
            [CurrencyKey] ASC
        ) WITH (
            PAD_INDEX = OFF, 
            STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, 
            ALLOW_ROW_LOCKS = ON, 
            ALLOW_PAGE_LOCKS = ON, 
            OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF
        ) ON [PRIMARY]
    ) ON [PRIMARY]
END
