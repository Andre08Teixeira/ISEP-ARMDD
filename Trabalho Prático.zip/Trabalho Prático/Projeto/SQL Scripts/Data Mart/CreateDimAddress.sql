IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CreateDimAddress')
BEGIN
    CREATE TABLE [dbo].[CreateDimAddress](
        [AddressKey] [int] IDENTITY(1,1) NOT NULL,
        [AddressLine1] [varchar](50) NOT NULL,
        [AddressLine2] [varchar](50) NOT NULL,
        [City] [nvarchar](50) NOT NULL,
        [PostalCode] [int] NOT NULL,
        [StateProvinceCode] [int] NOT NULL,
        [StateProvinceName] [varchar](50) NOT NULL,
        [CountryRegionCode] [int] NOT NULL,
        [CountryRegionName] [varchar](50) NOT NULL,
        [Territory] [varchar](50) NOT NULL,
        CONSTRAINT [PK_CreateDimAddress] PRIMARY KEY CLUSTERED 
        (
            [AddressKey] ASC
        ) WITH (
            PAD_INDEX = OFF, 
            STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, 
            ALLOW_ROW_LOCKS = ON, 
            ALLOW_PAGE_LOCKS = ON, 
            OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF
        ) ON [PRIMARY]
    ) ON [PRIMARY]
END
