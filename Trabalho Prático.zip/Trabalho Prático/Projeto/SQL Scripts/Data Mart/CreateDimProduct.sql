IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CreateDimProduct')
BEGIN
    CREATE TABLE [dbo].[CreateDimProduct](
        [ProductKey] [int] IDENTITY(1,1) NOT NULL,
        [ProductSubCategoryName] [varchar](50) NOT NULL,
        [ProductCategoryName] [varchar](50) NOT NULL,
        [Name] [nvarchar](50) NOT NULL,
        [FinishedGoodsFlag] [bit] NOT NULL,
        [SafetyStockLevel] [int] NOT NULL,
        [ReorderPoint] [int] NOT NULL,
        [StandardCost] [int] NOT NULL, -- Corrigido para [StandardCost]
        [ListPrice] [int] NOT NULL,
        [Size] [nvarchar](15) NOT NULL,
        [Weight] [decimal](8,2) NOT NULL,
        [WeightUnitMeasure] [nchar](3) NOT NULL,
        [SubCategoryName] [nvarchar](50) NOT NULL,
        [CategoryName] [nvarchar](50) NOT NULL,
        [Color] [nvarchar](15) NOT NULL,
        [DaysToManufacture] [int] NOT NULL,
        [SizeUnitMeasure] [nchar](3) NOT NULL,
        [Class] [nvarchar](10) NOT NULL,
        [Style] [nvarchar](10) NOT NULL,
        [SellStartDate] [date] NOT NULL,
        [SellEndDate] [date] NOT NULL,
        [CreatedDate] [date] NOT NULL,
        [ModifiedDate] [date] NOT NULL,
        CONSTRAINT [PK_CreateDimProduct] PRIMARY KEY CLUSTERED 
        (
            [ProductKey] ASC
        ) WITH (
            PAD_INDEX = OFF, 
            STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, 
            ALLOW_ROW_LOCKS = ON, 
            ALLOW_PAGE_LOCKS = ON, 
            OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF
        ) ON [PRIMARY]
    ) ON [PRIMARY]
END
