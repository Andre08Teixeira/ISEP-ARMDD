IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CreateDimEmployee')
BEGIN
    CREATE TABLE [dbo].[CreateDimEmployee](
        [EmployeeKey] [int] IDENTITY(1,1) NOT NULL,
        [NationIDNumber] [varchar](50) NOT NULL,
        [PersonType] [varchar](50) NOT NULL,
        [PersonTitle] [nvarchar](50) NOT NULL,
        [Gender] [int] NOT NULL,
        [FirstName] [varchar](50) NOT NULL,
        [MiddleName] [varchar](50) NOT NULL,
        [LastName] [varchar](50) NOT NULL,
        [JobTitle] [varchar](50) NOT NULL,
        [BirthDate] [varchar](50) NOT NULL,
        [MaritalStatus] [varchar](50) NOT NULL,
        [HireDate] [nvarchar](50) NOT NULL,
        [SalariedFlag] [int] NOT NULL,
        [VacationHours] [int] NOT NULL,
        [SickLeaveHours] [varchar](50) NOT NULL,
        [IsCurrent] [int] NOT NULL,
        [EffectiveDate] [varchar](50) NOT NULL,
        [ExpirationDate] [varchar](50) NOT NULL,
        CONSTRAINT [PK_CreateDimEmployee] PRIMARY KEY CLUSTERED 
        (
            [EmployeeKey] ASC
        ) WITH (
            PAD_INDEX = OFF, 
            STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, 
            ALLOW_ROW_LOCKS = ON, 
            ALLOW_PAGE_LOCKS = ON, 
            OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF
        ) ON [PRIMARY]
    ) ON [PRIMARY]
END
